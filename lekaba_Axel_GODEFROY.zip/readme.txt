1) Tapez "npm start"
2) Rendez vous sur http://localhost:8080
